<?php
/**
 * Plugin Name: Custom Block Plugin
 * Description: Un plugin personalizado de bloque para WordPress.
 * Version: 1.0.0
 * Author: Juana Contreras
 */
 // Registrar y cargar el bloque personalizado
 function custom_block_plugin_init() {
     // Registrar el bloque
     register_block_type('custom-block-plugin/block', array(
         'editor_script' => 'custom-block-script',
         'render_callback' => 'custom_block_render_callback',
     ));
 }
 add_action('init', 'custom_block_plugin_init');
 
 // Callback de renderizado del bloque
 function custom_block_render_callback($attributes) {
     $category = get_category_by_slug($attributes['category']);
     $category_class = '';
 
     // Obtener la clase de la categoría
     if ($category) {
         $category_class = 'category-' . $category->slug;
     }
 
     // Generar el código HTML del bloque
     $output = '<div class="custom-block ' . $category_class . '">';
     $output .= '<h2>' . esc_html($attributes['title']) . '</h2>';
     $output .= '<p>' . esc_html($attributes['description']) . '</p>';
     $output .= '</div>';
 
     return $output;
 }
 
 // Cargar el script del editor
 //
 function custom_block_editor_script() {
     // Registrar el script del editor
     wp_register_script(
         'custom-block-script',
         plugins_url('my-first-block/editor-script.js', __FILE__),
         array('wp-blocks', 'wp-element')
     );
 
     // Pasar las categorías al script del editor
     wp_localize_script(
         'custom-block-script',
         'customBlockCategories',
         array(
             'nacional' => array(
                 'background' => '#00B049',
                 'text'       => '#FFFFFF',
             ),
             'entretenimiento' => array(
                 'background' => '#FFC915',
                 'text'       => '#FFFFFF',
             ),
             'tecnologia' => array(
                 'background' => '#00D3F8',
                 'text'       => '#FFFFFF',
             ),
             'mascotas' => array(
                 'background' => '#90456D',
                 'text'       => '#FFFFFF',
             ),
             'deportes' => array(
                 'background' => '#FF372C',
                 'text'       => '#FFFFFF',
             ),
         )
     );
 
     // Cargar el script del editor
     wp_enqueue_script('custom-block-script');
 }
 add_action('enqueue_block_editor_assets', 'custom_block_editor_script');
 