(function (blocks, element, editor, i18n, components) {
    var el = element.createElement;
    var registerBlockType = blocks.registerBlockType;
    var InspectorControls = editor.InspectorControls;
    var PanelBody = components.PanelBody;
    var SelectControl = components.SelectControl;

    registerBlockType('custom-block-plugin/block', {
        title: 'Custom Block',
        description: 'Bloque personalizado para WordPress.',
        icon: 'smiley',
        category: 'common',
        attributes: {
            title: {
                type: 'string',
                default: 'Título',
            },
            description: {
                type: 'string',
                default: 'Descripción',
            },
            category: {
                type: 'string',
                default: '',
            },
        },
        edit: function (props) {
            var attributes = props.attributes;

            function onChangeTitle(value) {
                props.setAttributes({
                    title: value,
                });
            }

            function onChangeDescription(value) {
                props.setAttributes({
                    description: value,
                });
            }

            function onChangeCategory(value) {
                props.setAttributes({
                    category: value,
                });
            }

            return [
                el(
                    InspectorControls,
                    { key: 'inspector' },
                    el(
                        PanelBody,
                        { title: 'Configuración del bloque', initialOpen: true },
                        el(SelectControl, {
                            label: 'Categoría',
                            value: attributes.category,
                            options: Object.keys(customBlockCategories).map(function (key) {
                                return {
                                    value: key,
                                    label: key.charAt(0).toUpperCase() + key.slice(1),
                                };
                            }),
                            onChange: onChangeCategory,
                        })
                    )
                ),
                el(
                    'div',
                    { className: props.className },
                    el('h2', {}, el(editor.RichText, {
                        tagName: 'span',
                        inline: true,
                        placeholder: 'Título',
                        value: attributes.title,
                        onChange: onChangeTitle,
                    })),
                    el('p', {}, el(editor.RichText, {
                        tagName: 'span',
                        inline: true,
                        placeholder: 'Descripción',
                        value: attributes.description,
                        onChange: onChangeDescription,
                    })))
            ];
        },
        save: function (props) {
            return null; // El bloque se renderizará en el callback de renderizado
        },
    });
})(window.wp.blocks, window.wp.element, window.wp.editor, window.wp.i18n, window.wp.components);
